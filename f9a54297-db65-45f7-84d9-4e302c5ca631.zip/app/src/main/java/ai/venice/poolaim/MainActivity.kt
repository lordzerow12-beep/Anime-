package ai.venice.poolaim

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(56, 120, 56, 56)
        }

        val title = TextView(this).apply {
            text = "Pool Aim"
            textSize = 28f
            setTextColor(Color.BLACK)
            setPadding(0, 0, 0, 20)
        }

        status = TextView(this).apply {
            textSize = 15f
            setTextColor(Color.DKGRAY)
            setPadding(0, 0, 0, 40)
        }

        val bOverlay = Button(this).apply {
            text = "1. Allow drawing over other apps"
            setOnClickListener {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        }

        val bStart = Button(this).apply {
            text = "2. Start overlay"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    status.text = "Grant the overlay permission first."
                } else {
                    askProjection()
                }
            }
        }

        val bStop = Button(this).apply {
            text = "Stop overlay"
            setOnClickListener {
                startService(
                    Intent(this@MainActivity, OverlayService::class.java)
                        .setAction(OverlayService.ACTION_STOP)
                )
            }
        }

        root.addView(title)
        root.addView(status)
        root.addView(bOverlay)
        root.addView(bStart)
        root.addView(bStop)

        setContentView(ScrollView(this).apply { addView(root) })

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 3)
        }
    }

    override fun onResume() {
        super.onResume()
        status.text = if (Settings.canDrawOverlays(this))
            "Permission granted.\n\nOpen 8 Ball Pool, return here, press Start, then go back to the game."
        else
            "Overlay permission NOT granted. Tap button 1."
    }

    private fun askProjection() {
        val m = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(m.createScreenCaptureIntent(), 2)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 2 && res == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, OverlayService::class.java)
                    .setAction(OverlayService.ACTION_START)
                    .putExtra("code", res)
                    .putExtra("data", data)
            )
        }
    }
}
