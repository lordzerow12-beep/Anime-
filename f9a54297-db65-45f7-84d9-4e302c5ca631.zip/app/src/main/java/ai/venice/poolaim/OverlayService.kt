package ai.venice.poolaim

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import org.opencv.android.OpenCVLoader

class OverlayService : Service() {

    companion object {
        const val ACTION_START = "start"
        const val ACTION_STOP = "stop"
        const val CH = "poolaim"
    }

    private var view: OverlayView? = null
    private var wm: WindowManager? = null
    private var lp: WindowManager.LayoutParams? = null
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var lastFrame = 0L
    private var busy = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        OpenCVLoader.initLocal()
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CH, "Overlay", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, CH)
            .setContentTitle("Pool Aim")
            .setContentText("Overlay active")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
        wm = getSystemService(WindowManager::class.java)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        val data = intent?.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY
        showOverlay()
        startCapture(intent.getIntExtra("code", 0), data)
        return START_STICKY
    }

    private fun showOverlay() {
        if (view != null) return
        val v = OverlayView(this) { touchable -> setTouch(touchable) }
        view = v
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        lp = p
        wm?.addView(v, p)
    }

    private fun setTouch(touchable: Boolean) {
        val p = lp ?: return
        p.flags = if (touchable)
            p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        else p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        view?.let { wm?.updateViewLayout(it, p) }
    }

    private fun startCapture(code: Int, data: Intent) {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val p = mpm.getMediaProjection(code, data) ?: return
        projection = p

        val dm = resources.displayMetrics
        val w = (dm.widthPixels * 0.6f).toInt()
        val h = (dm.heightPixels * 0.6f).toInt()

        thread = HandlerThread("cap").also { it.start() }
        handler = Handler(thread!!.looper)

        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        reader!!.setOnImageAvailableListener({ r -> onImage(r) }, handler)

        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, handler)

        vd = p.createVirtualDisplay(
            "cap", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, handler
        )
    }

    private fun onImage(r: ImageReader) {
        val now = System.currentTimeMillis()
        if (now - lastFrame < 130 || busy) { r.acquireLatestImage()?.close(); return }
        lastFrame = now

        val img = r.acquireLatestImage() ?: return
        busy = true
        try {
            val plane = img.planes[0]
            val pix = plane.pixelStride
            val row = plane.rowStride
            val w = img.width
            val h = img.height
            val padded = w + (row - pix) / pix
            val full = Bitmap.createBitmap(padded, h, Bitmap.Config.ARGB_8888)
            plane.buffer.rewind()
            full.copyPixelsFromBuffer(plane.buffer)
            val bmp = Bitmap.createBitmap(full, 0, 0, w, h)

            val v = view
            if (v != null && v.mode == OverlayView.Mode.RUN) {
                val d = Vision.process(bmp, v.calib)
                if (d != null) v.submit(d)
            }
        } catch (t: Throwable) {
        } finally {
            img.close()
            busy = false
        }
    }

    override fun onDestroy() {
        view?.let { runCatching { wm?.removeView(it) } }
        reader?.close()
        vd?.release()
        projection?.stop()
        thread?.quitSafely()
        super.onDestroy()
    }
}
