package ai.venice.poolaim

import android.graphics.RectF
import kotlin.math.hypot
import kotlin.math.max

data class Pt(val x: Float, val y: Float)

data class Ball(val c: Pt, val r: Float, val colour: Int)

data class Fan(val path: List<Pt>, val ghost: Pt, val target: Pt, val colour: Int)

object Predict {

    private const val MAXB = 4

    fun fan(cue: Pt, cueR: Float, balls: List<Ball>, box: RectF): List<Fan> {
        val out = ArrayList<Fan>()
        for (b in balls) {
            val dx = b.c.x - cue.x
            val dy = b.c.y - cue.y
            val m = hypot(dx, dy)
            if (m < cueR * 1.5f) continue
            val d = Pt(dx / m, dy / m)
            val ghost = Pt(b.c.x + d.x * cueR * 2f, b.c.y + d.y * cueR * 2f)
            val target = Pt(b.c.x + d.x * cueR * 12f, b.c.y + d.y * cueR * 12f)
            out.add(Fan(bounce(b.c, d, box, b.r), ghost, target, b.colour))
        }
        return out
    }

    fun cuePath(cue: Pt, cueR: Float, balls: List<Ball>, box: RectF): List<Pt>? {
        val near = balls.minByOrNull { hypot(it.c.x - cue.x, it.c.y - cue.y) } ?: return null
        val dx = near.c.x - cue.x
        val dy = near.c.y - cue.y
        val m = hypot(dx, dy)
        if (m < 1e-3f) return null
        return bounce(cue, Pt(dx / m, dy / m), box, cueR)
    }

    private fun bounce(start: Pt, dir: Pt, box: RectF, r: Float): List<Pt> {
        val path = ArrayList<Pt>().apply { add(start) }
        var p = start
        var d = dir
        var n = 0
        while (n < MAXB) {
            var t = Float.MAX_VALUE
            var axis = 0
            var sign = 1f
            if (d.x > 1e-4f) { val v = (box.right - r - p.x) / d.x; if (v > 0.5f && v < t) { t = v; axis = 1; sign = -1f } }
            if (d.x < -1e-4f) { val v = (box.left + r - p.x) / d.x; if (v > 0.5f && v < t) { t = v; axis = 1; sign = 1f } }
            if (d.y > 1e-4f) { val v = (box.bottom - r - p.y) / d.y; if (v > 0.5f && v < t) { t = v; axis = 2; sign = -1f } }
            if (d.y < -1e-4f) { val v = (box.top + r - p.y) / d.y; if (v > 0.5f && v < t) { t = v; axis = 2; sign = 1f } }
            if (t == Float.MAX_VALUE) break
            p = Pt(p.x + d.x * t, p.y + d.y * t)
            path.add(p)
            val mm = max(hypot(d.x, d.y), 1e-5f)
            d = if (axis == 1) Pt(-d.x / mm, d.y / mm) else Pt(d.x / mm, -d.y / mm)
            n++
        }
        return path
    }
}
