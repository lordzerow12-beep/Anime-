package ai.venice.poolaim

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

class OverlayView(
    ctx: Context,
    private val onTouchModeChange: (Boolean) -> Unit
) : View(ctx) {

    enum class Mode { IDLE, CALIBRATE, RUN }

    var mode = Mode.IDLE
        set(v) { field = v; onTouchModeChange(v != Mode.RUN); invalidate() }

    var calib: FloatArray? = null
        private set

    private var det: Vision.Det? = null
    private var fans: List<Fan> = emptyList()
    private var cuePath: List<Pt>? = null

    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3.2f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.6f
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ui = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(185, 18, 18, 18) }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 40f }

    private val calRect = RectF()
    private val closeRect = RectF()

    init {
        val raw = ctx.getSharedPreferences("poolaim", Context.MODE_PRIVATE).getString("calib", null)
        if (raw != null) {
            val parts = raw.split(",")
            if (parts.size == 12) calib = FloatArray(12) { parts[it].toFloat() }
        }
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        calRect.set(w / 2 - 200f, 30f, w / 2 + 200f, 128f)
        closeRect.set(w - 140f, 30f, w - 34f, 128f)

        if (mode == Mode.IDLE) {
            canvas.drawRoundRect(calRect, 18f, 18f, ui)
            canvas.drawText(if (calib == null) "CALIBRATE" else "RECALIBRATE", calRect.left + 34f, calRect.centerY() + 14f, txt)
            canvas.drawRoundRect(closeRect, 18f, 18f, ui)
            canvas.drawText("X", closeRect.centerX() - 13f, closeRect.centerY() + 14f, txt)
            calib?.let { dots(canvas, it) }
            return
        }

        if (mode == Mode.CALIBRATE) {
            canvas.drawText("Tap pocket " + ((calib?.size ?: 0) / 2 + 1) + " of 6", 60f, 110f, txt)
            calib?.let { dots(canvas, it) }
            return
        }

        val d = det ?: return
        val sx = w / d.capW
        val sy = h / d.capH
        val rv = d.cueR * sx

        fill.color = Color.WHITE
        canvas.drawCircle(d.cue.x * sx, d.cue.y * sy, rv, fill)

        cuePath?.let { p ->
            line.color = Color.WHITE
            line.strokeWidth = 4.2f
            for (i in 1 until p.size) canvas.drawLine(p[i - 1].x * sx, p[i - 1].y * sy, p[i].x * sx, p[i].y * sy, line)
            line.strokeWidth = 3.2f
        }

        for (f in fans) {
            line.color = f.colour
            ring.color = f.colour
            fill.color = f.colour

            for (i in 1 until f.path.size) {
                canvas.drawLine(f.path[i - 1].x * sx, f.path[i - 1].y * sy, f.path[i].x * sx, f.path[i].y * sy, line)
            }
            canvas.drawCircle(f.ghost.x * sx, f.ghost.y * sy, rv, ring)
            canvas.drawCircle(f.target.x * sx, f.target.y * sy, 5.5f, fill)
        }
    }

    private fun dots(canvas: Canvas, arr: FloatArray) {
        fill.color = Color.rgb(255, 214, 0)
        for (i in 0 until arr.size / 2) canvas.drawCircle(arr[i * 2] * width, arr[i * 2 + 1] * height, 13f, fill)
    }

    fun submit(d: Vision.Det) {
        det = d
        fans = Predict.fan(d.cue, d.cueR, d.balls, d.box)
        cuePath = Predict.cuePath(d.cue, d.cueR, d.balls, d.box)
        if (mode == Mode.RUN) postInvalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action != MotionEvent.ACTION_DOWN) return true
        val x = e.x
        val y = e.y

        if (mode == Mode.IDLE) {
            if (calRect.contains(x, y)) {
                calib = FloatArray(0)
                mode = Mode.CALIBRATE
            } else if (closeRect.contains(x, y)) {
                context.stopService(Intent(context, OverlayService::class.java))
            }
            return true
        }

        if (mode == Mode.CALIBRATE) {
            val cur = calib ?: FloatArray(0)
            if (cur.size >= 12) return true
            val next = cur.copyOf(cur.size + 2)
            next[cur.size] = x / width
            next[cur.size + 1] = y / height
            calib = next
            if (next.size == 12) {
                context.getSharedPreferences("poolaim", Context.MODE_PRIVATE)
                    .edit().putString("calib", next.joinToString(",")).apply()
                Vision.reset()
                mode = Mode.RUN
            }
            invalidate()
            return true
        }
        return true
    }
}
