package ai.venice.poolaim

import android.graphics.Bitmap
import android.graphics.RectF
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.core.MatOfDouble
import org.opencv.core.MatOfPoint
import org.opencv.core.MatOfPoint2f
import org.opencv.core.Point
import org.opencv.core.Rect
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import kotlin.math.hypot
import kotlin.math.max

object Vision {

    data class Det(val cue: Pt, val cueR: Float, val balls: List<Ball>, val box: RectF, val capW: Int, val capH: Int)

    private var lastCue: Pt? = null

    fun process(bmp: Bitmap, calib: FloatArray?): Det? {
        if (calib == null || calib.size < 12) return null

        val src = Mat()
        Utils.bitmapToMat(bmp, src)
        val cw = src.cols().toFloat()
        val ch = src.rows().toFloat()

        var minX = cw; var maxX = 0f; var minY = ch; var maxY = 0f
        for (i in 0 until 6) {
            val x = calib[i * 2] * cw
            val y = calib[i * 2 + 1] * ch
            if (x < minX) minX = x
            if (x > maxX) maxX = x
            if (y < minY) minY = y
            if (y > maxY) maxY = y
        }
        val padX = (maxX - minX) * 0.010f
        val padY = (maxY - minY) * 0.010f
        val box = RectF(
            (minX + padX).coerceIn(0f, cw - 2),
            (minY + padY).coerceIn(0f, ch - 2),
            (maxX - padX).coerceIn(2f, cw),
            (maxY - padY).coerceIn(2f, ch)
        )
        if (box.width() < 60 || box.height() < 40) return null

        val roi = Mat(src, Rect(box.left.toInt(), box.top.toInt(), box.width().toInt(), box.height().toInt()))
        val scale = 480.0 / roi.cols()
        val small = Mat()
        Imgproc.resize(roi, small, Size(480.0, roi.rows() * scale))

        val hsv = Mat()
        Imgproc.cvtColor(small, hsv, Imgproc.COLOR_RGB2HSV)
        val valCh = Mat()
        Core.extractChannel(hsv, valCh, 2)

        val lab = Mat()
        Imgproc.cvtColor(small, lab, Imgproc.COLOR_RGB2Lab)

        val mean = MatOfDouble()
        val std = MatOfDouble()
        Core.meanStdDev(lab, mean, std)
        val m = mean.toArray()
        val s = std.toArray()

        val bg = Mat()
        Core.inRange(
            lab,
            Scalar(m[0] - max(2.4 * s[0], 11.0), m[1] - max(2.4 * s[1], 7.0), m[2] - max(2.4 * s[2], 7.0)),
            Scalar(m[0] + max(2.4 * s[0], 11.0), m[1] + max(2.4 * s[1], 7.0), m[2] + max(2.4 * s[2], 7.0)),
            bg
        )
        val mask = Mat()
        Core.bitwise_not(bg, mask)

        val dark = Mat()
        Core.inRange(valCh, Scalar(0.0), Scalar(72.0), dark)
        Core.bitwise_not(dark, dark)
        Core.bitwise_and(mask, dark, mask)

        val k = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, Size(3.0, 3.0))
        Imgproc.morphologyEx(mask, mask, Imgproc.MORPH_OPEN, k)
        Imgproc.morphologyEx(mask, mask, Imgproc.MORPH_CLOSE, k)

        val contours = ArrayList<MatOfPoint>()
        Imgproc.findContours(mask, contours, Mat(), Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)

        val found = ArrayList<Ball>()
        val centre = Point()
        val rad = FloatArray(1)

        for (c in contours) {
            val area = Imgproc.contourArea(c)
            if (area < 16.0 || area > 500.0) continue
            Imgproc.minEnclosingCircle(MatOfPoint2f(*c.toArray()), centre, rad)
            val r = rad[0]
            if (r < 2.6f || r > 13f) continue
            val circ = area / (Math.PI * r * r).toFloat()
            if (circ < 0.55f) continue
            val col = colourOf(small, centre.x, centre.y, r)
            if (col == 0) continue
            found.add(Ball(Pt(centre.x.toFloat(), centre.y.toFloat()), r, col))
        }
        if (found.isEmpty()) return null

        val cueCands = found.filter { satOf(hsv, it.c, it.r) < 42.0 && brightOf(hsv, it.c, it.r) > 195.0 }
        val cue = if (cueCands.isEmpty()) null else {
            val prev = lastCue
            if (prev == null) cueCands.maxByOrNull { it.r }
            else cueCands.minByOrNull { hypot(it.c.x - prev.x, it.c.y - prev.y) }
        }
        if (cue == null) return null
        lastCue = cue.c

        val balls = found.filter { it !== cue }

        val sx = box.width() / small.cols()
        val sy = box.height() / small.rows()
        fun map(p: Pt) = Pt(box.left + p.x * sx, box.top + p.y * sy)

        return Det(map(cue.c), cue.r * sx, balls.map { Ball(map(it.c), it.r * sx, it.colour) }, box, bmp.width, bmp.height)
    }

    private fun colourOf(rgb: Mat, cx: Double, cy: Double, r: Float): Int {
        val step = (r * 0.6).toInt().coerceAtLeast(1)
        var rs = 0.0; var gs = 0.0; var bs = 0.0; var n = 0
        var dy = -step
        while (dy <= step) {
            var dx = -step
            while (dx <= step) {
                val x = (cx + dx).toInt()
                val y = (cy + dy).toInt()
                if (x >= 0 && y >= 0 && x < rgb.cols() && y < rgb.rows()) {
                    val px = rgb.get(y, x) ?: continue
                    bs += px[0]; gs += px[1]; rs += px[2]; n++
                }
                dx++
            }
            dy++
        }
        if (n < 6) return 0
        val r8 = (rs / n).toInt().coerceIn(0, 255)
        val g8 = (gs / n).toInt().coerceIn(0, 255)
        val b8 = (bs / n).toInt().coerceIn(0, 255)
        return android.graphics.Color.rgb(r8, g8, b8)
    }

    private fun satOf(hsv: Mat, c: Pt, r: Float): Double = meanChannel(hsv, c, r, 1)
    private fun brightOf(hsv: Mat, c: Pt, r: Float): Double = meanChannel(hsv, c, r, 2)

    private fun meanChannel(hsv: Mat, c: Pt, r: Float, idx: Int): Double {
        val step = (r * 0.6).toInt().coerceAtLeast(1)
        var sum = 0.0; var n = 0
        var dy = -step
        while (dy <= step) {
            var dx = -step
            while (dx <= step) {
                val x = (c.x + dx).toInt()
                val y = (c.y + dy).toInt()
                if (x >= 0 && y >= 0 && x < hsv.cols() && y < hsv.rows()) {
                    val px = hsv.get(y, x) ?: continue
                    sum += px[idx]; n++
                }
                dx++
            }
            dy++
        }
        return if (n == 0) 0.0 else sum / n
    }

    fun reset() { lastCue = null }
}
