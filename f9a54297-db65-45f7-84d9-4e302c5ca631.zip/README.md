# Pool Aim

Overlay that draws predicted ball paths for 8 Ball Pool.

## Install
1. Build with GitHub Actions, or `gradle assembleDebug` in Termux.
2. Install `app/build/outputs/apk/debug/app-debug.apk`.
3. Open the app, grant "Display over other apps".
4. Open 8 Ball Pool, then Start overlay and accept capture.

## Calibrate
Tap CALIBRATE, then the six pockets in order:
top-left, top-middle, top-right, bottom-left, bottom-middle, bottom-right.
Tap X to stop.

## Notes
Centre-ball simulation, 4 cushion bounces, no spin.
